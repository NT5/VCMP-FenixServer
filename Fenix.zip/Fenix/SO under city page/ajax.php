<?php
include 'config.php';
include 'functions.php';
session_start();
$ax_loge = ( isset( $_SESSION['pinfo'] ) ? true:false );
$ax_func = ( isset( $_GET['ax'] ) ? $_GET['ax']:null );
$ax_pass = ( isset( $_GET['uc'] ) ? $_GET['uc']:null );
//Pass = YWpheA==
if ( $ax_func && $ax_pass && base64_decode( $ax_pass ) == base64_decode( $ajax_code ) ) {
	$db = @mysql_connect( $mysql_host, $mysql_user, $mysql_pass );
	mysql_select_db( $mysql_data );
	switch( $ax_func ) {
		case "exist_user":
			if ( isset ( $_GET['src'] ) ) {
				$q = mysql_query( "select * from users where name = '".$_GET['src']."'" );
				echo ( mysql_num_rows( $q ) > 0 ? "true":"false" );
				mysql_free_result( $q );
			}
		break;
		case "chage_nick":
			if ( $ax_loge ) {
				if ( isset( $_GET['new'] ) ) {
					$pinfo = $_SESSION['pinfo'];
					$nick = array( 'old' => $pinfo['name'], 'new' => $_GET['new'] );
					$q = mysql_query( "SELECT * FROM users WHERE name = '".$nick['new']."'" );
					if ( mysql_num_rows( $q ) == 0 ) {
						mysql_query( "UPDATE users SET name = '".$nick['new']."', clan = '0' WHERE name = '".$nick['old']."'" );
						if ( $pinfo['ccars'] > 0 ) {
							mysql_query( "UPDATE cars SET owner = '".$nick['new']."' WHERE owner = '".$nick['old']."'" );
						}
						if ( $pinfo['cprops'] > 0 ) {
							mysql_query( "UPDATE properties SET owner = '".$nick['new']."' WHERE owner = '".$nick['old']."'" );
						}
						if ( $pinfo['cgotolocs'] > 0 ) {
							mysql_query( "UPDATE gotoloc SET creator = '".$nick['new']."' WHERE creator = '".$nick['old']."'" );
						}
						echo '0';
						session_destroy();
						mysql_query( "DELETE FROM who_online WHERE nick = '".$nick['old']."'" );
					}
					else {
						echo '1';
					}
					mysql_free_result( $q );
				}
			}
		break;
		case "get_opt":
			if ( isset ( $_GET['s'] ) ) {
				$q = mysql_query( "select * from web_coments where sec = '".$_GET['s']."' order by  date desc limit 0,50" );
				if ( mysql_num_rows( $q ) > 0 ) {
					echo "<div style=\"overflow-x:auto; overflow-y:auto; text-align: left; max-height: 200px;\">";
						while( $row = mysql_fetch_assoc( $q ) ) {
							echo "<a style=\"text-decoration:none; font-size:0.9em; font-weight:bold; color:blue;\" href=\"?action=profile&player=".base64_encode($row["nick"])."\"><b>".$row["nick"]."</b></a>: ".$row["text"]."<br/>";
						}
					echo "</div>";
					mysql_free_result( $q );
				}
				else echo '<img src="/files/resources/icons/warning.png"/>&nbsp;No Comments Here!';
			}
		break;
		case "new_comment":
			if ( $ax_loge ) {
				if ( isset( $_GET['s'] ) && isset( $_GET['t'] ) ) {
					$text = strip_tags( $_GET['t'] );
					$sec = strip_tags( $_GET['s'] );
					if ( $text && $sec ) {
						$sql = "insert into web_coments (nick, text, sec) values( '".$_SESSION['pinfo']["name"]."', '".$text."', '".$sec."' )";
						if ( mysql_query( $sql ) ) {
							echo 'true';
						}
					}
				}
			}
		break;
		case "swep_save":
			if ( $ax_loge ) {
				if ( isset( $_GET['s'] ) ) {
					$sql = "update users set weps = '".$_GET['s']."' where name = '".$_SESSION['pinfo']["name"]."'";
					if ( mysql_query( $sql ) ) {
						echo 'true';
					}
				}
			}
		break;
		case "get_info_store":
			if ( $ax_loge ) {
				$result = array();
				function addresult( $sql ) {
					global $result;
					$q = mysql_query( $sql );
					array_push( $result, mysql_num_rows( $q ) );
					mysql_free_result( $q );
				}
				$res = array( 
					"select * from cars",
					"select * from cars where owner != 'Vice City'",
					"select * from properties",
					"select * from properties where owner != 'Vice City'"
				);
				foreach( $res as $sql ) {
					addresult( $sql );
				}
				$buffer = null;
				foreach( $result as $buf ) {
					$buffer = ( $buffer ? $buffer.'#'.$buf:$buf );
				}
				echo ( !$buffer ? "null":$buffer );
			}
		break;
		case "get_store":
			if ( $ax_loge ) {
				if ( isset( $_GET['place'] ) && isset( $_GET['id'] ) ) {
					$show_place = $_GET['place'];
					$show_id = $_GET['id'];
					if ( $show_place && $show_id ) {
						if ( $show_place == 'cars' ) {
							$q = mysql_query( "select * from cars where _rowid = ".$show_id."" );
							if ( mysql_num_rows( $q ) > 0 ) {
								$result = mysql_fetch_assoc( $q );
								$base_cars = '/files/vc_images/vc_vehicles/';
								?>
								<div id="store_info_" style="display:none;" class="box02">
									<div style="float:left; position:relative;">
									<? if ( $result["owner"] != "Vice City" ) echo '<img style="width:50px; height:66px; float:left; position:absolute; top:0px; left:0px;" src="/files/resources/img/sold_red.png"/>'; ?>
									<img style="border-radius:5px; width:50px; height:50px; float:left;" src="<? echo $base_cars.$result["model"].'.jpg'?>"/>
									<p>
									<h3><? echo VehicleNameFromModel($result["model"]).' - #'.$result["id"];?></h3>
									Owner: <? echo ( $result["owner"] != "Vice City" ? '<a style="text-decoration:none; font-size:0.9em; font-weight:bold; color:blue;" href="?action=profile&player='.base64_encode($result["owner"]).'">'.$result["owner"].'</a>':"None" ); ?> -
									<? if ( $result["shared"] != "None" ) { echo 'Shared: '.$result["shared"].' - '; } ?>
									Position: <? $sp = split( ' ', $result["pos"] ); $area = GetAreaName( $sp[0], $sp[1] ); echo( $area ? $area:"Vici City" );?> -
									Price: <? echo '$'.number_format( $result["cost"], 0, '', ',' );?>
									</p>
									</div>
								</div>
								<?
								mysql_free_result( $q );
							}
						}
						else if ( $show_place == 'props' ){
							$q = mysql_query( "select * from properties where _rowid = ".$show_id."" );
							if ( mysql_num_rows( $q ) > 0 ) {
								$result = mysql_fetch_assoc( $q );
								$pick_base = '/files/vc_images/vc_props/';
								$id = $result["id"];
								$pick = ( file_exists('.'.$pick_base.$id.'.png' ) ? $pick_base.$id.'.png':$pick_base.'default.png' );
								?>
								<div id="store_info_" style="display:none;" class="box02">
									<div style="float:left; position:relative;">
									<? if ( $result["owner"] != "Vice City" ) echo '<img style="width:50px; height:66px; float:left; position:absolute; top:0px; left:0px;" src="/files/resources/img/sold_red.png"/>'; ?>
									<img style="border-radius:5px; width:50px; height:50px; float:left;" src="<? echo $pick;?>"/>
									<p>
									<h3><? echo $result["name"].' - #'.$result["id"];?></h3>
									Owner: <? echo ( $result["owner"] != "Vice City" ? '<a style="text-decoration:none; font-size:0.9em; font-weight:bold; color:blue;" href="?action=profile&player='.base64_encode($result["owner"]).'">'.$result["owner"].'</a>':"None" ); ?> -
									<? if ( $result["shared"] != "None" ) { echo 'Shared: '.$result["shared"].' - '; } ?>
									Position: <? $sp = split( ' ', $result["pos"] ); $area = GetAreaName( $sp[0], $sp[1] ); echo( $area ? $area:"Vici City" );?> -
									Price: <? echo '$'.number_format( $result["cost"], 0, '', ',' );?>
									</p>
									</div>
								</div>
								<?
								mysql_free_result( $q );
							}
						}
					}
				}
			}
		break;
	}
	mysql_close( $db );
}
?>