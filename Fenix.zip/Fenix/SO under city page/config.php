<?php

//Configuracion de las variables para establecer la coneccion MySQL
$mysql_host = 'nt5.hopto.org';
$mysql_user = 'squirrel';
$mysql_pass = 'squirrelsql';
$mysql_data = 'none';

$config_active_pages = array(
	'#' => 'Home',
	'live' => 'Map',
	'profile' => 'Profile',
	'irc_chat' => 'Irc',
	'store' => 'Store',
	'memories' => 'Memories',
	'top' => 'Tops',
	'staff' => 'Staff',
	'members' => 'Members',
);

$forb_pages = array( 
	'members',
	'me',
	'seach',
	'log_out',
	'error'
);

#$server_json = array('192.168.1.3','8081','/data.json');

$page_config = array(
	'forum_rss' => 'http://forum.nt5.com.ar/index.php?app=core&module=global&section=rss&type=forums&id=1',
	'forum' => 'http://forum.nt5.com.ar/',
);

$ajax_code = base64_encode('ajax');

?>