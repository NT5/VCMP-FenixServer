/* Java Script By Hendel */

window.onload = function(){
	showlayer( 'load_bar', false );
	ax_pass = ax_myvar;
	ax_resp = false;
	vcmp_getinfo();
		jQuery.noConflict();
		jQuery(document).ready(function() {
			jQuery("#gotop").hide();
			jQuery(function () {
				jQuery(window).scroll(function () {
				if (jQuery(this).scrollTop() > 600) {
					jQuery('#gotop').fadeIn();
				} else {
					jQuery('#gotop').fadeOut();
				}
			});
			jQuery('#gotop a').click(function () {
				jQuery('body,html').animate({
				scrollTop: 0
				}, 800);
				return false;
			});
		});
	});
}

/* Server */
function vcmp_getinfo(){
	var json_url = function(){var buffer = "http://"; for( var val in json_info ) buffer+=json_info[val]; return buffer;};
	jQuery.ajax({
	  url: json_url(),
	  dataType: 'json',
	  data: {},
	  success: function(e){j_Server=e;showlayer( "vcmp_online", false );},
	  timeout: 3000,
	  error: function(jqXHR, status, errorThrown){ showlayer( "vcmp_online", true ); }
	});
}

var vcmp = {
	vector_X: function(x){return(560 + ( x / 3.90 ))},
	vector_Y: function(y){return(560 - ( y / 3.82 ))},
	colorate: function(s,c){
		var colors = {black:"000000",snow:"cdc9c9",blue:"0000ff",green:"006400",yellow:"ffff00",brown:"8b4513",orange:"ffa500",pink:"ff69b4",red:"ff0000"};
		return '<span style="color:#'+(typeof colors[c] != 'undefined' ? colors[c]:colors.black)+';">'+s+'</span>';
	},
	weathers: ["Partly cloudy","Overcast cloudy skies","Lightning","Fog with low visibility","Clear skies","Rain","Darkness from the eclipse","Light sky, partly cloudy","Overcast partly cloudy","Grey sky, black clouds"],
	weapons: {0:"Unarmed",1:"Brass Knuckles",2:"Screwdriver",3:"Golf Club",4:"Nightstick",5:"Knife",6:"Baseball Bat",7:"Hammer",8:"Meat Cleaver",9:"Machete",10:"Katana",11:"Chainsaw",12:"Grenade",13:"Remote Detonation Grenade",14:"Tear Gas",15:"Molotov Cocktails",16:"Rocket",17:"Colt45",18:"Python",19:"Shotgun",20:"SPAZ Shotgun",21:"Stubby Shotgun",22:"Tec9",23:"Uzi",24:"Silenced Ingram",25:"MP5",26:"M4",27:"Ruger",28:"Sniper Rifle",29:"Laser Sniper Rifle",30:"Rocket Launcher",31:"Flame Thrower",32:"M60",33:"Minigun",42:"Drive-By",43:"Drowned",60:"Heli Blade",255:"Suicide"},
	bodyparts: ["Body","Torso","Left Arm","Right Arm","Left Leg","Right Leg","Head"],
	skins: {0:'Tommy Vercetti',1:'Cop',2:'Swat',3:'FBI',4:'Army',5:'Paramedic',6:'Fireman',7:'Golf guy #1',9:'Bum lady #1',10:'Bum lady #2',11:'Punk #1',12:'Lawyer',13:'Spanish lady #1',14:'Spanish lady #2',15:'Cool guy #1',16:'Arabic guy',17:'Beach lady #1',18:'Beach lady #2',19:'Beach guy #1',20:'Beach guy #2',21:'Office lady #1',22:'Waitress #1',23:'Food lady',24:'Prostitue #1',25:'Bum lady #2',26:'Bum guy #1',27:'Garbageman #1',28:'Taxi driver #1',29:'Hatian #1',30:'Criminal #1',31:'Hood lady',32:'Granny #1',33:'Business man #1',34:'Church guy',35:'Club lady',36:'Church lady',37:'Pimp',38:'Beach lady #3',39:'Beach guy #3',40:'Beach lady #4',41:'Beach guy #4',42:'Business man #2',43:'Prostitute #2',44:'Bum lady #3',45:'Bum guy #2',46:'Hatian #2',47:'Construction worker #1',48:'Punk #2',49:'Prostitute #2',50:'Granny #2',51:'Punk #3',52:'Business man #3',53:'Spanish lady #3',54:'Spanish lady #4',55:'Cool guy #2',56:'Business man #4',57:'Beach lady #5',58:'Beach guy #5',59:'Beach lady #6',60:'Beach guy #6',61:'Construction worker #2',62:'Golf guy #2',63:'Golf lady',64:'Golf guy #3 ',65:'Beach lady #7',66:'Beach guy #7',67:'Office lady #2',68:'Business man #5',69:'Business man #6',70:'Prostitute #2',71:'Bum lady #4',72:'Bum guy #3',73:'Spanish guy',74:'Taxi driver #2',75:'Gym lady',76:'Gym guy',77:'Skate lady',78:'Skate guy',79:'Shopper #1',80:'Shopper #2',81:'Tourist #1',82:'Tourist #2',83:'Cuban #1',84:'Cuban #2',85:'Hatian #3',86:'Hatian #4',87:'Shark #1',88:'Shark #2',89:'Diaz guy #1',90:'Diaz guy #2',91:'DBP security #1',92:'DBP security #2',93:'Biker #1',94:'Biker #2',95:'Vercetti guy #1',96:'Vercetti guy #2',97:'Undercover cop #1',98:'Undercover cop #2',99:'Undercover cop #3',100:'Undercover cop #4',101:'Undercover cop #5',102:'Undercover cop #6',103:'Rich guy',104:'Cool guy #3',105:'Prostitute #3',106:'Prostitute #4',107:'Love Fist #1',108:'Ken Rosenburg',109:'Candy Suxx',110:'Hilary',111:'Love Fist #2',112:'Phil',113:'Rockstar guy',114:'Sonny',115:'Lance',116:'Mercades',117:'Love Fist #3',118:'Alex Srub',119:'Lance (Cop)',120:'Lance',121:'Cortez',122:'Love Fist #3',123:'Columbian guy #1',124:'Hilary (Robber)',125:'Mercades',126:'Cam',127:'Cam (Robber)',128:'Phil (One arm)',129:'Phil (Robber)',130:'Cool guy #4',131:'Pizzaman',132:'Taxi driver #1',133:'Taxi driver #2',134:'Sailor #1',135:'Sailor #2',136:'Sailor #3',137:'Chef',138:'Criminal #2',139:'French guy',140:'Garbageman #2',141:'Hatian #5',142:'Waitress #2',143:'Sonny guy #1',144:'Sonny guy #2',145:'Sonny guy #3',146:'Columbian guy #2',147:'Thug #1',148:'Beach guy #8',149:'Garbageman #3',150:'Garbageman #4',151:'Garbageman #5',152:'Tranny',153:'Thug #5',154:'SpandEx guy #1',155:'SpandEx guy #2',156:'Stripper #1',157:'Stripper #2',158:'Stripper #3',159:'Store clerk'},
	messages: {
		partreason: ["Timeout","Quit","Kicked","Banned","Crashed"],
		team: {
			colors: ["#778898","#ff8d13","#c715ff","#20b1aa","#ffd720","#dc143b","#6395ec","#ff1494","#f4a361","#ee82ef","#8b4512","#f0e78c","#148a8a","#14ff7f","#566b30","#191971","#ffffff","#ffffff"],
			parse: function(e) { return typeof this.colors[e] != "undefined" ? this.colors[e]:"#ffffff" }
		},
		parse_player: function(t,n){ return '<span style="color:'+this.team.parse(t)+'";>'+n+'</span>';
		},
		parse: function(e) {
			switch( e.type ){
				case 0: return e.msg;
				case 1: return '> '+this.parse_player(e.team,e.name)+vcmp.colorate(' join to server','green' )+'country: '+vcmp.colorate(e.country,"blue")+'.'; break;
				case 2: return '> '+this.parse_player(e.team,e.name)+vcmp.colorate(' left the server','red')+'('+this.partreason[e.reason]+')'; break;
				case 3: return '> '+this.parse_player(e.team,e.name)+vcmp.colorate(' spawned on ','orange')+vcmp.skins[e.skin]+'.'; break;
				case 4: return vcmp.colorate('* ','brown')+this.parse_player(e.team,e.name)+': '+e.msg; break;
				case 5: return '** '+this.parse_player(e.team,e.name)+': '+vcmp.colorate(e.msg,'pink'); break;
				case 6: return '> '+this.parse_player(e.team,e.name)+vcmp.colorate(' Dead. ','red')+'('+vcmp.weapons[e.reason]+')'; break;
				case 7: return '> '+this.parse_player(e.team,e.name)+vcmp.colorate(' kill ','red')+this.parse_player(e.vteam,e.victim)+' ('+vcmp.weapons[e.reason]+') ('+vcmp.bodyparts[e.bodypart]+')'; break;
				case 8: return '> '+this.parse_player(e.team,e.name)+vcmp.colorate(' kill ','red')+this.parse_player(e.vteam,e.victim)+' ('+vcmp.weapons[e.reason]+') ('+vcmp.bodyparts[e.bodypart]+')'; break;
				case 9: return '* '+this.parse_player(e.team,e.name)+': '+e.msg; break;
			}
		}
	}
};

function select_text(a){
  var e = document.getElementById(a);
  if (window.getSelection) {
      var s = window.getSelection();
      if (s.setBaseAndExtent) { s.setBaseAndExtent(e, 0, e, e.innerText.length - 1);}
      else {
        if (window.opera && e.innerHTML.substring(e.innerHTML.length - 4) == '<BR>'){ e.innerHTML = e.innerHTML + ' ';}
        var r = document.createRange();
        r.selectNodeContents(e);
        s.removeAllRanges();
        s.addRange(r);
      }
  }
  else if (document.getSelection) {
      var s = document.getSelection();
      var r = document.createRange();
      r.selectNodeContents(e);
      s.removeAllRanges();
      s.addRange(r);
  }
  else if (document.selection) {
      var r = document.body.createTextRange();
      r.moveToElementText(e);
      r.select();
  }
}
function strip_html( string ) {
    return string.replace(/<[^>]+>/g,'');
}

/* Ajax */
function objajax(){
 var xmlhttp=false;
  try{
   xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
  }catch(e){
   try {
    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
   }catch(E){
    xmlhttp = false;
   }
  }
  if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
   xmlhttp = new XMLHttpRequest();
  }
  return xmlhttp;
}

function SendAjaxResquest( param ) {
	ajax_return = null;
	var ax = objajax();
	ax.open( "GET", param, null );
	ax.send(null);
	return ax.responseText;
}

function ExistPlayer() {
 showloadbar();
 var cont = document.getElementById('log_user');
 var img_div = document.getElementById('com_log01');
 var ax = objajax();
 ax.open( "GET", "ajax.php?ax=exist_user&uc="+ax_pass+"&src="+strip_html( cont.value ) );
 ax.onreadystatechange=function() {
  if (ax.readyState==4) {
   if(ax.responseText == 'false'){
	cont.style.background='#ff0000';
	img_div.style.display = "";
	}
   else {
   cont.style.background='#FFFFFF';
   img_div.style.display = "none";
   }
  }
 }
 ax.send(null);
 showloadbar();
}

/* Comments */

function GetComments( sec ) {
	showloadbar();
	var ax = objajax();
	var output = document.getElementById( 'comments' );
	var box = 'comments_box';
	ax.open( "GET", "ajax.php?ax=get_opt&uc="+ax_pass+"&s="+sec );
	ax.onreadystatechange=function() {
		if (ax.readyState==4) {
			if ( document.getElementById( box ).style.display == "none" ) {
				showlayer( box );
			}
			output.innerHTML = "";
			output.innerHTML = ax.responseText;
		}
	}
	ax.send(null);
	showloadbar();
}

function NewComment( sec ) {
	var ax = objajax();
	var val_name = "new_comment";
	var val = strip_html ( document.getElementById( val_name ).value );
	if ( val.length > 0 ) {
		ax.open( "GET", "ajax.php?ax=new_comment&uc="+ax_pass+"&s="+sec+"&t="+val );
		ax.onreadystatechange = function() {
			if ( ax.readyState == 4 ) {
				if ( ax.responseText == 'true' ) {
					document.getElementById( val_name ).value = "";
					GetComments( sec );
				}
			}
		}
		ax.send(null);
	}
}

/* JQuery */
function closefloatlogin() {
	setTimeout("showlayer('login_float')", 3000);
}
function showloadbar(){
	showlayer('load_bar');
}
function showlayer2( bloq ) {
	jQuery(document).ready(function ($) {
		$("#"+bloq).slideToggle();
	});
}
function showlayer( bloq, x ) {
	var obj = document.getElementById( bloq ), param;
	param = ( typeof x == 'undefined' ? null:x );
	if ( obj ) {
		if ( x != null ) {
			if ( x == true ) {
				jQuery(document).ready(function ($) {
					$("#"+bloq).fadeIn(200);
				});
			}
			else if ( x == false ) {
				jQuery(document).ready(function ($) {
					$("#"+bloq).fadeOut(200);
				});
			}
		}
		else {
			if (obj.style.display=='none') {
				jQuery(document).ready(function ($) {
					$("#"+bloq).fadeIn(200);
				});
			}
			else {
				jQuery(document).ready(function ($) {
					$("#"+bloq).fadeOut(200);
				});
			}
		}
	}
}