<?php
/********************************
*								*
*	Squirrel Server Functions	*
*		NT5's VC:MP Script		*
*								*
********************************/

function InPoly($point, $polygon) {
    if($polygon[0] != $polygon[count($polygon)-1])
        $polygon[count($polygon)] = $polygon[0];
    $j = 0;
    $oddNodes = false;
    $x = $point[1];
    $y = $point[0];
    $n = count($polygon);
    for ($i = 0; $i < $n; $i++)
    {
        $j++;
        if ($j == $n)
        {
            $j = 0;
        }
        if ((($polygon[$i][0] < $y) && ($polygon[$j][0] >= $y)) || (($polygon[$j][0] < $y) && ($polygon[$i][0] >=
            $y)))
        {
            if ($polygon[$i][1] + ($y - $polygon[$i][0]) / ($polygon[$j][0] - $polygon[$i][0]) * ($polygon[$j][1] -
                $polygon[$i][1]) < $x)
            {
                $oddNodes = !$oddNodes;
            }
        }
    }
    return $oddNodes;
}

function GetAreaName( $x, $y ) {
	include 'config.php';
	$db = mysql_connect( $mysql_host, $mysql_user, $mysql_pass );
	mysql_select_db( $mysql_data );
	$q = mysql_query( "SELECT * FROM area" );
	
	$point_a = array( $x, $y );
	while( $row = mysql_fetch_array( $q ) ) {
		$row_points = split( ",", $row[0] );
		$p_count = 0;
		$p_buf = array();
		$polygon = array();
		foreach( $row_points as $point ) {
			array_push( $p_buf, $point );
			$p_count++;
			if ( $p_count == 2 ) {
				array_push( $polygon, $p_buf );
				$p_count = 0;
				$p_buf = array();
			}
		}
		if ( InPoly( $point_a, $polygon ) ) return $row[1];
	}
	mysql_free_result( $q );
	mysql_close( $db );
}

function GetWeaponName( $wep ) {
	switch( $wep ) {
	 case 0: return 'Fist'; break;
	 case 1: return 'Brass Knuckle'; break;
	 case 2: return 'Screwdriver'; break;
	 case 3: return 'Golf Club'; break;
	 case 4: return 'Nightstick'; break;
	 case 5: return 'Knife'; break;
	 case 6: return 'Baseball Bat'; break;
	 case 7: return 'Hammer'; break;
	 case 8: return 'Cleaver'; break;
	 case 9: return 'Machete'; break;
	 case 10: return 'Katana'; break;
	 case 11: return 'Chainsaw'; break;
	 case 12: return 'Grenades'; break;
	 case 13: return 'Remote Grenades'; break;
	 case 14: return 'Teargas'; break;
	 case 15: return 'Molotov Cocktails'; break;
	 case 16: return 'Missile'; break;
	 case 17: return 'Colt45'; break;
	 case 18: return 'Python'; break;
	 case 19: return 'Shotgun'; break;
	 case 20: return 'Spaz'; break;
	 case 21: return 'Stubby'; break;
	 case 22: return 'Tec9'; break;
	 case 23: return 'Uzi'; break;
	 case 24: return 'Silenced Ingram'; break;
	 case 25: return 'MP5'; break;
	 case 26: return 'M4'; break;
	 case 27: return 'Ruger'; break;
	 case 28: return 'Sniper Rifle'; break;
	 case 29: return 'Laserscope Sniper Rifle'; break;
	 case 30: return 'Rocket Launcher'; break;
	 case 31: return 'Flamethrower'; break;
	 case 32: return 'M60'; break;
	 case 33: return 'Minigun'; break;
	}
}

function ValidWep( $wep ) {
	if ( $wep > 33 || $wep <= 0 || $wep == 33 || $wep == 13 || $wep == 16) return false;
	else return true;
}

function ParseWeapons( $string ) {
	$sweps = split( ",", $string );
	$slot_le = 7;
	$buffer = array( 0,0,0,0,0,0,0,0 );
	for( $i = 0; $i <= $slot_le; $i++ ) {
		if ( isset( $sweps[ $i ] ) ) {
			$slot = WepSlot( $sweps[ $i ] );
			$buffer[ $slot ] = $sweps[ $i ];
		}
	}
	return $buffer;
}

function GetSlotWapons( $slot ) {
	$weps = array();
	$i = 0;
	while( $i <= 33 ) {
		if ( ValidWep( $i ) ) {
			if ( WepSlot( $i ) === $slot ) {
				array_push( $weps, ( string ) $i );
			}
		}
		$i++;
	}
	return $weps;
}

function WepSlot( $wep ) {
	switch ( $wep ) {
	case 0:
	case 1:
		return 0;
	break;
	case 2:
	case 3:
	case 5:
	case 6:
	case 7:
	case 8:
	case 9:
	case 10:
	case 11:
		return 1;
	break;
	case 12:
	case 13:
	case 14:
	case 15:
		return 2;
	break;
	case 17:
	case 18:
		return 3;
	break;
	case 19:
	case 20:
	case 21:
		return 4;
	break;
	case 22:
	case 23:
	case 24:
	case 25:
		return 5;
	break;
	case 26:
	case 27:
		return 6;
	break;
	case 28:
	case 29:
		return 8;
	break;
	case 30:	
	case 31:
	case 32:
	case 33:
		return 7;
	break;
	default:
		return "Unknown";
	break;
	}
}

function VehicleNameFromModel( $model ) {
	switch( $model ) {
		case 130: return "Landstalker"; break;
		case 131: return "Idaho"; break;
		case 132: return "Stinger"; break;
		case 133: return "Linerunner"; break;
		case 134: return "Perennial"; break;
		case 135: return "Sentinel"; break;
		case 136: return "Rio"; break;
		case 137: return "Firetruck"; break;
		case 138: return "Trashmaster"; break;
		case 139: return "Stretch"; break;
		case 140: return "Manana"; break;
		case 141: return "Infernus"; break;
		case 142: return "Voodoo"; break;
		case 143: return "Pony"; break;
		case 144: return "Mule"; break;
		case 145: return "Cheetah #1"; break;
		case 146: return "Ambulance"; break;
		case 147: return "FBI Washington"; break;
		case 148: return "Moonbeam"; break;
		case 149: return "Esperanto"; break;
		case 150: return "Taxi"; break;
		case 151: return "Washington"; break;
		case 152: return "Bobcat"; break;
		case 153: return "Mr. Whoopee"; break;
		case 154: return "BF Injection"; break;
		case 155: return "Hunter"; break;
		case 156: return "Police"; break;
		case 157: return "Enforcer"; break;
		case 158: return "Securicar"; break;
		case 159: return "Banshee"; break;
		case 160: return "Predator"; break;
		case 161: return "Bus"; break;
		case 162: return "Rhino"; break;
		case 163: return "Barracks OL"; break;
		case 164: return "Cuban Hermes"; break;
		case 165: return "Helicopter"; break;
		case 166: return "Angel"; break;
		case 167: return "Coach"; break;
		case 168: return "Cabbie"; break;
		case 169: return "Stallion"; break;
		case 170: return "Rumpo"; break;
		case 172: return "Romero's Hearse."; break;
		case 173: return "Packer"; break;
		case 174: return "Sentinel XS"; break;
		case 175: return "Admiral"; break;
		case 176: return "Squalo"; break;
		case 177: return "Sea Sparrow"; break;
		case 178: return "Pizza boy"; break;
		case 179: return "Gang Burrito"; break;
		case 182: return "Speeder"; break;
		case 183: return "Reefer"; break;
		case 184: return "Tropic"; break;
		case 185: return "Flatbed"; break;
		case 186: return "Yankee"; break;
		case 187: return "Caddy"; break;
		case 188: return "Zebra Cab"; break;
		case 189: return "Top Fun"; break;
		case 190: return "Skimmer"; break;
		case 191: return "PCJ 600"; break;
		case 192: return "Faggio"; break;
		case 193: return "Freeway"; break;
		case 196: return "Glendale"; break;
		case 197: return "Oceanic"; break;
		case 198: return "Sanchez"; break;
		case 199: return "Sparrow"; break;
		case 200: return "Patriot"; break;
		case 201: return "Love Fist"; break;
		case 202: return "Coast Guard"; break;
		case 203: return "Dinghy"; break;
		case 204: return "Hermes"; break;
		case 205: return "Sabre"; break;
		case 206: return "Sabre Turbo"; break;
		case 207: return "Phoenix"; break;
		case 208: return "Walton"; break;
		case 209: return "Regina"; break;
		case 210: return "Comet"; break;
		case 211: return "Deluxo"; break;
		case 212: return "Burrito"; break;
		case 213: return "Spand Express"; break;
		case 214: return "Marquis"; break;
		case 215: return "Baggage Handler"; break;
		case 216: return "Kaufman Cab"; break;
		case 217: return "Maverick"; break;
		case 218: return "VCN Maverick"; break;
		case 219: return "Rancher"; break;
		case 220: return "FBI Rancher"; break;
		case 221: return "Virgo"; break;
		case 222: return "Greenwood"; break;
		case 223: return "Cuban Jetmax"; break;
		case 224: return "Hotring Racer #1"; break;
		case 225: return "Sandking"; break;
		case 226: return "Blista Compact"; break;
		case 227: return "Police Maverick"; break;
		case 228: return "Boxville"; break;
		case 229: return "Benson"; break;
		case 230: return "Mesa Grande"; break;
		case 232: return "Hotring Racer #2"; break;
		case 233: return "Hotring Racer #3"; break;
		case 234: return "Bloodring Banger #1"; break;
		case 235: return "Bloodring Banger #2"; break;
		case 236: return "Cheetah #2"; break;
		default: return "Unknown"; break;
	}
}

function VehicleModelFromName( $model ) {
	$max = 236;
	$min = 130;
	$veh = null;
	for( $i = $min; $i < $max; $i++ ) {
		$veh = VehicleNameFromModel( $i );
		similar_text( $veh, $model, $x );
		if ( $x > 80 ) return $i;
	}
	return "Unknown";
}

function LevelTag( $level ) {
	switch ( $level ) {
		case 0:
			return "No Registered";
			break;
		case 1:
			return "Member";
			break;
		case 2:
			return "Moderator";
			break;
		case 3:
			return "Admin";
			break;
		case 4:
			return "Management";
			break;
		case 5:
			return "Owner";
			break;	
		default:
			return "Unknown";
		break;
	}
}

function RankTag( $x, $level ) {
	switch ( $x ) {
		//Kills Rank
		case 0:
			if ( $level <= 99 ) return "Newbie";
			else if ( $level <= 199 ) return "Killer";
			else if ( $level <= 299 ) return "Extreme Killer";
			else if ( $level <= 399 ) return "Psycho";
			else if ( $level <= 499 ) return "Professional";
			else if ( $level <= 999 ) return "Pro. Legendary";
			else if ( $level >= 999 ) return "EXTREME LEGEND OF VCMP";
		break;
		//Pickups Rank
		case 1:
			if ( $level <= 99 ) return "Newbie Finder";
			else if ( $level <= 199 ) return "Best Seach";
			else if ( $level <= 299 ) return "Professional Searching";
			else if ( $level <= 399 ) return "Pro. Hunt";
			else if ( $level <= 999 ) return "Legend of Seach";
			else if ( $level >= 999 ) return "INSANE SEACH";
		break;
	}
}

#Ulr To Profile
function ParseAvatar( $string ) {
	$avatar = split( ';', $string );
	$avatar_url = array( 
		'skin' => './files/vc_images/vc_skins/'.$avatar[ 1 ].'.jpg',
		'url' => $avatar[ 1 ],
		'file' => './files/vc_images/profile_avatar/'.$avatar[ 1 ],
	);
	return $avatar_url[ $avatar[ 0 ] ];
}

#Php Functions
#RandomString
function randtext($len) {
	$srt = "1234567890abcdefghijklmnopqrstuvwxyz";
	for( $i=0; $i < $len; $i++ ) { $text .= $srt{ rand(0,35) }; }
	return $text;
}

#FirstArray
function array_first_value( $matriz ) {
	foreach ( $matriz as $key => $valor ) {
		return $valor;
	}
}
function array_first_key( $matriz ) {
	foreach ( $matriz as $key => $valor ) {
		return $key;
	}
}

#ConvertTime
function mktimefromsecs($input_seconds) {
	$days = "";
	$hours = "";
	$minutes = "";
	$seconds = "";
	$days = floor( $input_seconds / 86400 );
	$remainder = floor( $input_seconds % 86400 );
	$hours = floor( $remainder / 3600 );
	$remainder = floor( $remainder % 3600 );
	$minutes = floor( $remainder / 60 );
	$seconds = floor( $remainder % 60 );

	if ( $days > 0 ) $days = $days.'day ';
	if ( $hours > 0 ) $hours = $hours.'hrs ';
	if ( $minutes > 0 ) $minutes = $minutes.'mins ';
	if ( $seconds > 0 ) $seconds = $seconds.'segs';
	return $days.$hours.$minutes.$seconds;
}
#Inter Explorer Detector
function IsIE() {
	return ( strstr($_SERVER["HTTP_USER_AGENT"], "MSIE") ? true:false );
}
#GetIp
function GetIp() {
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) { return $_SERVER['HTTP_CLIENT_IP']; }
	else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { return $_SERVER['HTTP_X_FORWARDED_FOR']; }
	else return $_SERVER['REMOTE_ADDR'];
}
#GetIpLoc
function GetIpLoc( $ip ) {
	require("./files/resources/geoip.inc");
	$gi = geoip_open("./files/resources/GeoIP.dat", GEOIP_STANDARD);
	$ip = $ip;
	$Pais = strtoupper(geoip_country_name_by_addr($gi, $ip) );
	return ( $Pais ? $Pais:'Unknown' );
	geoip_close($gi);
}
#Exec Time
function microtime_float() {
	list($useg, $seg) = explode(" ", microtime());
	return ((float)$useg + (float)$seg);
}
?>