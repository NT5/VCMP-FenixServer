<?php	
	session_start();
	include 'config.php';
	include 'functions.php';

	$exec_script = microtime_float();
	$db = @mysql_connect( $mysql_host, $mysql_user, $mysql_pass );
	@mysql_select_db( $mysql_data );
	//MySQL Server Error Page.
	if ( !$db ) {
		$mysql_error = true;
		include 'files/resources/mysql_error.php';
		exit;
	}
	
	$page_ = array();
	$SQL = mysql_query("select * from data");
	while ( $row = mysql_fetch_array( $SQL ) ) { 
		$page_[$row['name']] = $row['param']; 
	}
	mysql_free_result( $SQL );
	
	if ( !$page_ ) {
		$mysql_error = true;
		include 'files/resources/mysql_error.php';
		exit;
	}
	
	if ( isset( $_POST['pass'] ) && isset( $_POST['user'] ) ) {
		$name = strip_tags( $_POST['user'] );
		$pass = strip_tags( $_POST['pass'] );
		if ( $name && $pass ) {
			$q = mysql_query("select * from users where name = '".$name."' and password = '".$pass."'");
			if ( mysql_num_rows( $q ) > 0 ) {
				$_SESSION['pinfo'] = mysql_fetch_assoc( $q );
				$login_show = "You are now signed in.";
			}
			else {
				$login_show = "Username or password incorrect.";
			}
			mysql_free_result( $q );
		}
		else {
			$login_show = "Type a valid Username or password.";
		}
	}

	$Logged = ( isset ( $_SESSION['pinfo'] ) ? true:false );

	$act = ( isset ( $_GET['action'] ) ? $_GET['action']:null );
	$pinfo = ( $Logged ? $_SESSION['pinfo']:null );
	
	$infoc = isset( $server_json ) ? $server_json:split(';', $page_["server_js"]);
	$vcmp_ip = ($infoc[0]==GetIp() ? "localhost":$infoc[0]); $vcmp_port = $infoc[1]; $vcmp_qu = $infoc[2];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title><?php echo $page_["server_name"].' Web Admin';?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="NT5">
<meta name="keywords" content="NT5, VC:MP, VC, Squirrel, mIRC, Script, Stats, Live, Map, Bot, IRC, Query, Under, City">
<link href='http://fonts.googleapis.com/css?family=Gudea:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/files/resources/style.css" />
<script language="JavaScript">
	var json_info = {
		ip: '<?echo $vcmp_ip;?>',
		port: ':<?echo $vcmp_port;?>',
		url: '<?echo $vcmp_qu;?>'
	};
</script>
<script language="JavaScript" src ="/files/resources/script.js"></script>
<script language="JavaScript" src ="/files/resources/jquery.js"></script>

<script language="JavaScript">ax_myvar = "<? echo $ajax_code;?>"</script>
</head>
<body>
	<? if ( IsIE() ) { ?>
	<div style="background:#f0ff23; text-align: center;" id="ie_suck"><b>Your browser maybe not support some elements on this page.</b></div>
	<? } ?>
	<div style="display:none; background:#ff0000; text-align: center;" id="vcmp_online"><b>The server is offline and the information is not correct please back later.</b></div>
	<div class="load_bar" id="load_bar"><img src="files/resources/loader.gif">Loading...</div>
	<div id="header">
		<div id="navigation">
			<ul>
				<?
				foreach( $config_active_pages as $url => $title ) {
				if ( $url == 'profile' && $Logged ) echo "<li><a href=\"?action=".$url."&player=".base64_encode( $pinfo['name'] )."\">".$title."</a>\n";
				else { ?>
				<li><a href="?action=<?echo $url;?>"><?echo $title;?></a></li>
				<? }} ?>
			</ul>
		</div>
		<!-- end of navigation -->	
		<div id="navigation2">
			<ul style="float:left;">
				<form action="?action=seach" method="post">
				<li>Search User: <input type="�text"� name="seach_username" class="yourclass"�/></li>
				<li><input type="submit"� name="seach_submit" class="yourclass"�/></li>
				</form>
			</ul>
			<? if ( $Logged ) { ?>
			<ul style="float:right;">
				<li>Hello! <?echo $pinfo["name"].', Connected from: '.GetIp();?></li>
				<li><input type="button"� value="Log Out" class="yourclass" onclick="window.location.href='?action=log_out'"�/></li>
			</ul>
			<? } ?>
		</div>
		<!-- end of navigation2 -->	
	</div>
	<!-- end of header -->
	<div class="container">
		<div id="wrap">
			<div id="content">	
			<?php
				if ( isset ( $login_show ) ) {
				echo '<div class="load_bar" id="login_float">'.$login_show.'</div>';
				echo '<script language="JavaScript">closefloatlogin();</script>'; 
				}
				if ( $Logged ) {
					$pinfo = $_SESSION['pinfo'];
					
					//Who's Online
					$who_o = array();
					$who_sql = null;
					$who_o["time"] = 15;
					$who_o["date"] = time();
					$who_o["ip"] = GetIp();
					$who_o["nick"] = $pinfo["name"];
					$who_o["sec"] = ( array_key_exists( $act, $config_active_pages ) ? $config_active_pages[ $act ]:"Home" );
					$who_o["limit"] = $who_o["date"] - $who_o["time"] * 60;

					mysql_query( "DELETE FROM who_online WHERE date < ".$who_o["limit"] );
					$who_sql = mysql_query( "SELECT * FROM who_online WHERE nick = '".$who_o["nick"]."'" );
					if ( mysql_num_rows( $who_sql ) != 0 ) {
						mysql_query( "UPDATE who_online SET date='".$who_o["date"]."', sec = '".$who_o["sec"]."' WHERE nick = '".$who_o["nick"]."'" );
					}
					else {
						mysql_query( "INSERT INTO who_online ( nick,date,ip,sec ) VALUES( '".$who_o["nick"]."', ".$who_o["date"].", '".$who_o["ip"]."', '".$who_o["sec"]."' )" );
					}
					mysql_free_result( $who_sql );
					//End of Online
					
					if ( !$act ) {
						if ( $page_["is_install"] ) {
							$visits = array();
							$date = date('ljF');
							$visits["src"] = ( isset( $page_["web_visits"] ) ? $page_["web_visits"]:"0,0,".$date."" );
							
							$visits["src"] = split( ',', $visits["src"] );
							$visits["src"][0]++;
							if ( $visits["src"][2] == $date ) {
								$visits["src"][1]++;
							}
							$visits["src"][2] = $date;
							$buffer = null;
							foreach( $visits["src"] as $x ) {
								$buffer = ( $buffer ? $buffer.','.$x:$x );
							}
							if ( $buffer ) {
								if ( isset( $page_["web_visits"] ) ) {
									mysql_query( "UPDATE data set param = '".$buffer."' where name = 'web_visits'" );
								}
								else {
									mysql_query( "INSERT INTO data ( name, param ) VALUES( 'web_visits', '".$buffer."' )" );
								}
							}
							
							$players = mysql_query("select * from users where isonline = 'true'");
							$sql = mysql_query("select * from users");
							?>
							<h1><?echo $page_["server_name"].' Web Status'?></h1>
							<div style="float:left; padding:15px;">
							<p>
								<ul>
								<b>Game Mode: </b><? echo $page_["server_game"];?>
								<br/>
								<b>Players: </b><? echo mysql_num_rows( $players ) . "/" . $page_["server_players"]; ?>
								<br/>
								<b>Ip: </b><? echo $page_["server_ip"];?>
								<br/>
								<b>Uptime: </b><? echo mktimefromsecs( time() - $page_["last_run"] );?>
								<br/>
								<b>Register users: </b><? echo number_format(mysql_num_rows( $sql ), 0, '', ',');?>
								<br/>
								<b>Last Member: </b><?$member = mysql_result( $sql, ( mysql_num_rows( $sql ) - 1 ), 1 );?><a href="?action=profile&player=<?echo base64_encode( $member );?>"><?echo $member;?></a>
								<br/>
								<b>News: </b><? echo ( isset( $page_["server_news"] ) ? $page_["server_news"]:"None" )."\n"; ?>
								<br/>
								</ul>
								<ul>
								<li><b>- Irc Echo Bot Info</b></li>
								<b>Server: </b><? echo $page_["bot_netname"];?>
								<br/>
								<b>Name: </b><? echo $page_["bot_name"];?>
								<br/>
								<b>Channel: </b><? echo $page_["bot_chan"];?>
								</ul>
							</p>
							</div>
							<div style="float:left; padding:15px;" width="480" height="270">
							<link href="/files/resources/video/video-js.css" rel="stylesheet" type="text/css"/>
							<script src="/files/resources/video/video.js"></script>
							<video id="video_1" class="video-js vjs-default-skin" controls preload="auto" width="480" height="270"
							poster="/files/resources/img/Under_City_Logo.png"
							data-setup="{}">
							<source src="/files/resources/video/under_city.mp4" type='video/mp4' />
							</video>
							
							</div>
							<br/>
							<?
								if ( mysql_num_rows( $players ) > 0 ) { ?>
									<div style="padding:15px;">
										<ul>
										<li><b>- Players on Server</b></li>
										<? while( $row = mysql_fetch_assoc( $players ) ) { ?>
											&raquo; <a style="text-decoration:none; color:#000000" href="?action=profile&player=<? echo base64_encode($row["name"]);?>"><b><? echo $row["name"]; ?></b></a>
											<br/>
										<? } ?>
										</ul>
									</div>
								<? } ?>
								<br/>
								<?
								@mysql_free_result( $sql );
								@mysql_free_result( $players );
								?>
								<div style="padding: 8px; width: 90%; margin: 0 auto;">
									<? 
									$who_sql = mysql_query( "SELECT * FROM who_online" );
									$count = mysql_num_rows( $who_sql );
									?>
									<ul>
									<li><b>- Web Status</b></li>
									<b><?echo $count;?> users are online (in the past 15 minutes)</b>
									<br/>
									<?
										$buffer = null;
										while( $row = mysql_fetch_assoc( $who_sql ) ) {
											$buffer = ( $buffer ? $buffer.', '.'<a style="color:blue; text-decoration:none;" href="?action=profile&player='.base64_encode( $row["nick"] ).'">'.$row["nick"].'</a> ('.$row["sec"].')':'<a style="color:blue; text-decoration:none;" href="?action=profile&player='.base64_encode( $row["nick"] ).'">'.$row["nick"].'</a> ('.$row["sec"].')' );
										}
										echo( $buffer ? '<b>'.$buffer.'</b>':"<b>No Users Online</b>" );
										mysql_free_result( $who_sql );
									?>
									<p style="float: right;">
										&raquo; <b>Visits Today:</b> <?echo $visits["src"][1];?>, &raquo; <b>All Visits:</b> <?echo $visits["src"][0];?>
									</p>
									<br/>
									<br/>
									<b>- <a style="color:blue; text-decoration:none;" target="_blank" href="<? echo $page_config["forum"];?>">Forum </a>News</b>
									<br/>
									<?php
										include './files/resources/class.rsslib.php';
										echo RSS_Forum( $page_config["forum_rss"] );
									?>
									</ul>
								</div>
							<div style="float: right; padding:15px; width:30%; height:10px; overflow:hidden;">
							<!-- facebook button -->
							<div id="fb-root"></div>
							<script>
								(function(d, s, id) {
									var js, fjs = d.getElementsByTagName(s)[0];
									if (d.getElementById(id)) return;
									js = d.createElement(s); js.id = id;
									js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
									fjs.parentNode.insertBefore(js, fjs);
									}(document, 'script', 'facebook-jssdk'));
								</script>
									<div class="fb-like" data-href="http://<?echo $_SERVER['HTTP_HOST'];?>/" data-send="false" data-width="450" data-show-faces="false" data-colorscheme="dark"></div>
							<!-- end of facebook button -->
							</div>
							<br/>
							<br/>
							<?								
						}
						else {
							echo '<br/><h3>The server has not yet been launched for the first Time.</h3>';
						}					
					}
					
					else if ( $act == 'live' ) {
					?>
						<h1><?echo $page_["server_name"];?> Live Map</h1>
						<br/>
						<style type="text/css">#map_menu p {color:#ffffff;}</style>
						<center>
						<div id="map_macro" style="z-index:2; width:768px; height:1024px; background: url(/files/vc_images/map.png);">
						<div class="map_head">
						<a href="#" onclick="showlayer2('map_menu'); return false;"><div id="map_head_bar" style="height:25px;width:760px;"><img src="files/resources/loader.gif"></div></a>
						<div id="map_menu" style="display:none;">
							<ul>
							<li class="box" id="box_info_jsout">
							<span id="info_jsout"><img src="files/resources/loader.gif"></span>
							</li>
							<li class="box" id="box_players_jsout">
							<span id="players_jsout"><img src="files/resources/loader.gif"></span>
							</li>
							<li id="box_chatbox_jsout">
							<span id="chatbox_jsout"><img src="files/resources/loader.gif"></span>
							</li>
							</ul>
						</div>
						</div>
						</div>
						</center>
						<br/>
						<ul>
						<small> Automatic update in 5secs</small>
						</ul>
						<script type="text/javascript">
						var players = [];
						var contents = {
							head_bar: document.getElementById('map_head_bar'),
							macro: document.getElementById('map_macro'),
							info: document.getElementById('info_jsout'),
							players: document.getElementById('players_jsout'),
							chatbox: document.getElementById('chatbox_jsout')
						};
						update();
						function update(){
							cleanmap();
							vcmp_getinfo();
							if ( typeof(j_Server) != "undefined" ) {
								var buffer = {
									players: { data: "", add: function(e){
										this.data += '<tr class="player_list" id="player_list_'+e.id+'"> <td class="id">'+e.id+'</td> <td class="name">'+e.name+'</td> <td class="score">'+e.score+'</td> <td class="ping">'+e.ping+'</td> </tr>';
									}},
									messages: { data: "", add: function(e){
										this.data += vcmp.messages.parse(e)+'<br/>';
									}}
								};
								for( e in j_Server.players ) {
									drawplayer(j_Server.players[e]);
									buffer.players.add(j_Server.players[e]);
								}
								for( e in j_Server.messages.reverse() ) {
									buffer.messages.add(j_Server.messages[e]);
								}
								var srt = {
									info: '<p>Server Name: '+j_Server.server.name+'<br/>Players: '+j_Server.server.numplayers+'/'+j_Server.server.maxplayers+'<br/>Weater: '+vcmp.weathers[j_Server.server.weather]+' - Time: '+j_Server.server.time.hour+':'+j_Server.server.time.minute+'</p>',
									players: '<table style="color:#ffffff;"><tr><td width="10">ID</td><td width="100">Name</td><td width="50">Score</td><td>Ping</td></tr><tr><div class="spacer"></div></tr>'+buffer.players.data+'</table>',
									chatbox: '<p>'+buffer.messages.data+'</p>',
									head_bar: '<span style="color:#ffffff;">'+j_Server.server.name+' Status Bar</span>'
								};
								for( e in srt ) contents[e].innerHTML = srt[e];
							}
							setTimeout( 'update();', 5000 );
						}
						function drawplayer( plr ) {
							if ( plr.spawned ) {
								var text = '[' + plr.id + '] ' + plr.name;
								var posx = vcmp.vector_X(plr.pos.x), posy = vcmp.vector_Y(plr.pos.y);
								var obj = document.createElement( 'div' );
								obj.setAttribute( 'style', 'left: ' + posx  + 'px; top: ' + posy + 'px;' );
								obj.setAttribute( 'class', 'cont_player' );
								obj.textContent = text;
								contents.macro.appendChild( obj );
								players.push( obj );
							}
						}
						
						function cleanmap() {
							if ( players.length > 0 ) {
								for ( var i = 0; i < players.length; i++ ) {
									if ( players[i] ) { contents.macro.removeChild( players[i] ); players[i] = null; }
								}
							}
						}
						</script>
					<?
					}
					
					else if ( $act == 'profile' && isset( $_GET['player'] ) ) {
						echo '<div id = "player_info" class = "box01">';
						$player = mysql_query("select * from users where name = '".base64_decode($_GET['player'])."'");
						if ( mysql_num_rows( $player ) > 0 ) {
							$player = mysql_fetch_assoc( $player );
						?>
							<h1><? echo $player["name"];?>'s profile on the server.</h1>
								<div class = "box01" style="width: 550px;">
								<?
								if ( isset( $_POST["new_profile_url"] ) ) {
									echo "
									<div id=\"saved_float\" class=\"load_bar\">Profile Picture Changed!</div>
									<script>
									setTimeout(\"showlayer('saved_float');\", 3000);
									</script>
									";
								}
								if ( $player["name"] == $pinfo["name"] && $player["isonline"] != "true" ) {
									$weapons = ( $player["weps"] != "0" ? $player["weps"]:"0,0" );
									?>
										<a onclick="showlayer('edit_box'); return false;" href="#" style="float:right; text-decoration:none; font-size:0.9em; font-weight:bold; color:blue;"><img src="/files/resources/icons/edit.png" />Edit Profile</a>
										<div class="profile_black" id="edit_box" style="display:none;">
										<div id="profile_edit" style="overflow-x:auto; overflow-y:auto;">
										<?
										if ( isset( $_POST["save_pro_spaw"] ) || isset( $_POST["save_pro"] ) ) {
											if ( isset( $_POST["save_pro_spaw"] ) ) {
												mysql_query( "UPDATE users SET avatar = 'skin;".$player["skin"]."' WHERE name = '".$player["name"]."'" );
												$player["avatar"] = "skin;".$player["skin"];
											}
											else if ( !empty( $_FILES['new_profile_up']['name'] ) ) {
												$valid_files = array( 'jpg', 'png', 'gif', 'jpeg' );
												$type = end( explode( ".", $_FILES['new_profile_up']['name'] ) );
												$path = './files/vc_images/profile_avatar/';
												if ( in_array( $type, $valid_files) ) {
													$filename = $player["name"].'_profile.prof';
													if ( move_uploaded_file( $_FILES['new_profile_up']['tmp_name'], $path.$filename ) ){
														mysql_query( "UPDATE users SET avatar = 'file;".$filename."' WHERE name = '".$player["name"]."'" );
														$player["avatar"] = 'file;'.$filename;
													}
												}
											}
											else if ( isset( $_POST["new_profile_url"] ) ) {
												if ( parse_url( $_POST["new_profile_url"], PHP_URL_SCHEME ) == 'http' ) {
													mysql_query( "UPDATE users SET avatar = 'url;".$_POST["new_profile_url"]."' WHERE name = '".$player["name"]."'" );
													$player["avatar"] = "url;".$_POST["new_profile_url"];
												}
											}
										}
										?>
										<div style="padding:5px;">
										<script lenguaje="javascript">
										function ChageNick() {
											showlayer( 'load_bar', true );
											var ax = objajax();
											var show = document.getElementById( 'nick_chage_show' );
											var date = document.getElementById( 'new_nick_i' );
											ax.open( "GET", "ajax.php?ax=chage_nick&uc="+ax_pass+"&new="+date.value );
											ax.onreadystatechange = function() {
												if ( ax.readyState == 4 ) {
													if ( ax.responseText == '0' ) {
														show.innerHTML = 'Profile Name Changed.';
														showlayer( 'nick_chage_show', true );
														document.location.reload( true );
													}
													else {
														show.innerHTML = 'This Nickname is already exist.';
														showlayer( 'nick_chage_show', true );
														setTimeout( "showlayer('nick_chage_show', false);", 1500 );
													}
													showlayer( 'load_bar', false );
												}
											}
											ax.send( null );
										}
										</script>
										<h3>Nickname</h3>
											<b>Current Nick: </b>
											<input id="new_nick_i" type="text" value="<?echo $player["name"];?>"/>
											<a style="text-decoration:none; color:blue; font-weight:bold;" onclick="ChageNick(); return false;" href="#">Save</a>
											<div style="display:none;" class="load_bar" id="nick_chage_show"></div>
										</div>
										<br/>
										<div class="spacer"></div>
										<div id="e_profile_avatar">
										<h3>Avatar</h3>
										<img style="width:50px;height:73px;float:left; padding:5px;" src="<?echo ParseAvatar( $player["avatar"] );?>"/>
										<form method="post" enctype="multipart/form-data"> 
											<p>Upload File: <input name="new_profile_up" type="file"/>
											<small>2mb max jpeg, jpg, png, gif</small>
											<br/>
											Select URL: <input name="new_profile_url" type="text"/>
											<br/>
											<br/>
											<input class="boton01" type="submit" name="save_pro_spaw" value="User Spawn Skin"/>
											<input class="boton01" type="submit" value="Save" name="save_pro"/>
											</p>
										</form>
										</div>
										<br/>
										<div class="spacer"></div>
										<div>
										<script lenguaje="javascript"> 
										function chagewep_img( id, newid ){
											var base = "/files/vc_images/vc_weapons/";
											document.getElementById( "img_wep_"+id ).src = base+newid+".png";
										}
										function showsaved() {
											showlayer( 'saved_float' );
											setTimeout("showlayer('saved_float')", 3000);
										}
										function parse_weps(){
											var base = "wep_";
											var total_slots = 7;
											var elt;
											var we_buffer = null;
											for ( var i = 0; i <= total_slots; i++ ) {
												elt = document.getElementById( base+i );
												if ( elt.value != "0" ) {
													we_buffer = ( we_buffer ? we_buffer+","+elt.value:elt.value );
												}
											}
											return ( we_buffer ? we_buffer:"0" );
										}
										function save_weapon() {
											showlayer( 'load_bar', true );
											var ax = objajax();
											var tosave = parse_weps();
											if ( tosave ) {
												ax.open( "GET", "ajax.php?ax=swep_save&uc="+ax_pass+"&s="+tosave );
												ax.onreadystatechange = function() {
													if ( ax.readyState == 4 ) {
														if ( ax.responseText == 'true' ) {
															showlayer( 'load_bar', false );
															showsaved();
														}
													}
												}
												ax.send(null);
											}
										}
										function we_turn_off(){
											showlayer( 'load_bar', true );
											var ax = objajax();
											ax.open( "GET", "ajax.php?ax=swep_save&uc="+ax_pass+"&s=0" );
											ax.onreadystatechange = function() {
												if ( ax.readyState == 4 ) {
													if ( ax.responseText == 'true' ) {
														var total_slots = 7;
														var base = "wep_";
														var elt;
														for ( var i = 0; i <= total_slots; i++ ) {
															elt = document.getElementById( base+i );
															elt.value = 0;
															chagewep_img( i, 0 );
														}
														showlayer( 'load_bar', false );
														showsaved();
													}
												}
											}
											ax.send(null);
										}
										</script> 
										<form name="form_weps">
										<h3>Spawn Weapons</h3>
										<div id="saved_float" style="display:none;" class="load_bar">Saved!</div>
										<span class="we_buttons">
											<a onclick="save_weapon(); return false;" style="text-decoration: none; color:blue; font-size: 0.9em; font-weight: bold;" href="#">Save</a> or <a onclick="we_turn_off(); return false;" style="text-decoration: none; color:#AD2930; font-size: 0.9em; font-weight: bold;" href="#">Turn Off</a>
										</span>
										<br/>
										<?
										$parse = ParseWeapons( $weapons );
										$slot = 0;
										foreach( $parse as $wep ) {
											$weapons_slot = GetSlotWapons( $slot );

											echo "<div class=\"wep_slot\"> \n\r";
											echo "<b>Slot: </b>".$slot."<br/> \n\r";
											echo "<img id=\"img_wep_".$slot."\" class=\"wep_slot\" src=\"/files/vc_images/vc_weapons/".( $wep ? $wep:"0" ).".png\"/> \n\r";
											echo "<br>\n\r";
											echo "<select onchange=\"chagewep_img( ".$slot.", this.options[this.selectedIndex].value );\" class=\"wep_slot\" size=\"1\" id=\"wep_".$slot."\"> \n\r";
											echo "<option ".( $wep == "0" ? "selected":"" )." value=\"0\">Empty</option>\n\r";
											foreach( $weapons_slot as $weap ) {
												echo ( $weap == $wep ? "<option selected value=\"".$weap."\">".GetWeaponName( $weap )."</option>":"<option value=\"".$weap."\">".GetWeaponName( $weap )."</option>" )."\n\r";
											}
											echo "</select><br/>\n\r";
											echo "</div> \n\r";
											$slot++;
										}
										?>
										</form>
										</div>
										<br/>
										<a onclick="showlayer('edit_box'); return false;" style="padding:.5em 1em; position: absolute; bottom: 0px; right: 0px; text-decoration: none;" href="#">Close</a>
										</div>
										</div>
									<?
								}
								?>
								<img style="float:right;width:30px;height:40px;" title="Status on server" src="/files/resources/icons/<?echo( $player["isonline"] == "true" ? "online":"offline")?>.png">
								<img style="width:50px;height:73px;border-radius:10px;float:left;" src="<?echo ParseAvatar( $player["avatar"] );?>"/>
									<b>Name: </b><? echo $player["name"];?> <br/>
									<?echo( $player["clan"] != "0" ? "<b>Clan: </b><a style=\"color:blue; text-decoration:none;\" href='?action=group&urc=clan&w=".base64_encode($player["clan"])."'>".$player["clan"]."</a><br/>":null);?>
									<b>Level: </b><? echo $player["level"].' ('.LevelTag( $player["level"] ).')';?> <br/>
									<b>Member Since: </b><? echo $player["datereg"];?> <br/>
									<b>Location: </b><? echo GetIpLoc( $player["ip"] );?> <br/>
									<br/>
									<div style="padding:14px; margin: 0 auto 0 auto;">
									<div class="boxstats" style="max-height: 185px;">
									<h3>Stats</h3>
									<b>Joins: </b><? echo $player["joins"];?> <br/>
									<b>Last Active: </b><? echo mktimefromsecs( time() - $player["lastactive"] );?> <br/>
									<b>Played Time: </b><? echo mktimefromsecs( $player["playedtime"] );?> <br/>
									<b>Pickups: </b><? echo $player["pickups"]." (".RankTag(1,$player["pickups"]).")";?> <br/>
									<b>Kills: </b><? echo $player["kills"]." (".RankTag(0,$player["kills"]).")";?> <br/>
									<b>Deaths: </b><? echo $player["deaths"];?> <br/>
									<b>Ratio: </b><? echo ( $player["deaths"] > 0 && $player["kills"] > 0 ? round( $player["kills"] / $player["deaths"], 2 ):0 );?> <br/>
									<b>Spree's: </b><? echo $player["spree"];?> <br/>
									</div>
									<div class="boxstats" style="max-height: 150px;">
									<h3>Word Stats</h3>
									<? $words = split(',', $player['wstats']); ?>
									<b>Letters: </b><?echo number_format( $words[0], 0, '', ',' );?><br/>
									<b>Words: </b><?echo number_format( $words[1], 0, '', ',' );?><br/>
									<b>Lines: </b><?echo number_format( $words[2], 0, '', ',' );?><br/>
									<b>Actions: </b><?echo number_format( $words[3], 0, '', ',' );?><br/>
									<b>Smiles: </b><?echo number_format( $words[4], 0, '', ',' );?><br/>
									</div>
									<div class="boxstats">
									<? $weapon = split(',', $player['westats']); ?>
									<h3>Weapon Stats</h3>
									<?
									$s = $weapon;
									$buffer = null;
									$fav = array();
									$favname = array();
									$i = 0;
									while( $i < 33 ){
										if ( $s[$i] != "0" ) {
											$buffer = ( $buffer != null ? $buffer." <b>".GetWeaponName( $i )."</b>: ".$s[$i].'<br/>':" <b>".GetWeaponName( $i )."</b>".": ".$s[$i].'<br/>' );
											$fav = ( $fav != null ? $fav.','.$s[$i]:$s[$i] );
											$favname = ( $favname != null ? $favname.','.GetWeaponName( $i ):GetWeaponName( $i ) );
										}
										$i++;
									}
									if ( $buffer ) {
										echo $buffer;
										$fav = split( ',', $fav );
										$favname = split( ',', $favname );
										arsort( $fav );
										echo "<br/>\n\r";
										echo "<b>Favorite Weapon:</b> ".$favname[ array_first_key( $fav ) ]." with ".array_first_value( $fav )." kills.\n\r";
									}
									else {
										echo "<b>Not Have Weapon Stats For This Player.</b>\n\r";
									}
									?>
									</div>
									<div class="boxstats">
									<h3>Body Stats</h3>
									<? $body = split(',', $player['bstats']); ?>
									<b>Body: </b><?echo $body[0];?><br/>
									<b>Torso: </b><?echo $body[1];?><br/>
									<b>Left Arm: </b><?echo $body[2];?><br/>
									<b>Right Arm: </b><?echo $body[3];?><br/>
									<b>Left Leg: </b><?echo $body[4];?><br/>
									<b>Right Leg: </b><?echo $body[5];?><br/>
									<b>Head: </b><?echo $body[6];?><br/>
									</div>
								</div>
								<div id="signature" class="boxstats">
									<h3>Signature</h3>
									<div class="shadown01">
										<img src="player.php?plr=<?echo $_GET['player'];?>"/>
									</div>
									<br/>
									<a onclick="showlayer('signature_share'); return false;" style="text-decoration:none; font-size:0.9em; font-weight:bold; color:blue;" href="#">Share...</a>
									<div id="signature_share" style="display:none;">
									<div style="float: left">
									<br/><b>HTML Code:</b><br/>
									<textarea rows="4" cols="30" onclick="this.select();" readonly="readonly" style="position: relative; margin: 0px; width: 335px; height: 112px; border: 1px solid black;"><? echo htmlspecialchars("<a href='http://".$_SERVER['HTTP_HOST']."/?action=profile&player=".$_GET['player']."'><img src='http://".$_SERVER['HTTP_HOST'].'/player.php?plr='.$_GET['player']."'></img></a>", ENT_QUOTES); ?>
									</textarea>
									</div>
									<div style="float: left">
									<br/><b>BB Code</b><br/>
									<textarea rows="4" cols="30" onclick="this.select();" readonly="readonly" style="position: relative; margin: 0px; width: 335px; height: 112px; border: 1px solid black;">[url=http://<?echo $_SERVER['HTTP_HOST'];?>/?action=profile&player=<?echo $_GET['player'];?>/][img]http://<?echo $_SERVER['HTTP_HOST'];?>/player.php?plr=<?echo $_GET['player'];?>[/img][/url]
									</textarea>
									</div>
									</div>
								</div>
						<?
						}
						else {
						?>
							<h1>Error Unknown Player.</h1>
						<?
						}
						?>
						</div>
						</div>
						<?
					}
					
					else if ( $act == 'group' && isset ( $_GET['urc'] ) ) {
						$sec = $_GET['urc'];
						$error = true;
						$show = array();
						switch( $sec ) {
							case "clan":
								if ( $_GET["w"] ) {
									$as = base64_decode( $_GET["w"] );
									$sql = mysql_query( "select * from users where clan = '".$as."' order by kills desc" );
									if ( mysql_num_rows( $sql ) > 0 ) {
										$count = 1;
										$total_kills = 0;
										array_push( $show, '<div id="cont_players">' );
										array_push( $show, '<h1>'.$as.' Member List</h1>' );
										array_push( $show, '<ul>- The Clan Have '.mysql_num_rows( $sql ).' Members.</ul>' );
										while ( $row = mysql_fetch_assoc( $sql ) ) {
											array_push( $show, "
												<div class='box01' style='width:500px; min-height:80px;'>
												<div>
												<img style='float:right;width:30px;height:40px;' title='Status on server' src='/files/resources/icons/".( $row["isonline"] == "true" ? "online":"offline").".png'/>
												<img style='width:50px;height:70px;border-radius:10px;float:left;' src='".ParseAvatar( $row["avatar"] )."'/>
												<a class='link01' href='?action=profile&player=".base64_encode($row["name"])."'><h3>#".$count.' '.$row["name"]."</h3></a>
												<p>Joined ".$row["datereg"]." -
												Kills: ".number_format( $row["kills"], 0, '', ',' )." - Deaths ".number_format( $row["deaths"], 0, '', ',' )."
												</p>
												</div>
												</div>
												<br/>
											" );
										$total_kills += $row["kills"];
										$count++;
										}
									array_push( $show, '<p>- <b>Clan Total Kills:</b> '.number_format( $total_kills, 0, '', ',' ).'</p>' );
									array_push( $show, '</div>' );
									mysql_free_result( $sql );
									$error = false;
									}
								}
							break;
						}
						if ( !$error ) {
							foreach( $show as $html ) {
								echo $html."\r\n";
							}
						}
						else {
							echo "<h1>Error on Your Consult please try again.</h1>";
						}
					}
					
					else if ( $act == 'seach' ) {
						if ( isset( $_POST["seach_submit"] ) && $_POST["seach_username"] ) {
							$seach = $_POST["seach_username"];
							$sql = mysql_query( "SELECT * FROM users WHERE name LIKE '%".$seach."%' LIMIT 0,10" );
							if ( mysql_num_rows( $sql ) > 0 ) {
								echo '<h1 align="center">"'.$seach.'" Search Sesult</h1>
										<div class="box01">
										<p><spam>- '.mysql_num_rows( $sql ).' result.</spam></p>';
								while ( $row = mysql_fetch_assoc( $sql ) ) {
									?>
									<div class="box01" style="width:500px; min-height:80px;">
									<div>
										<img style="float:right;width:30px;height:40px;" title="Status on server" src="/files/resources/icons/<?echo( $row["isonline"] == "true" ? "online":"offline")?>.png">
										<img style="width:50px;height:70px;border-radius:10px;float:left;" src="<?echo ParseAvatar( $row["avatar"] );?>"/>
										<a class="link01" href="?action=profile&player=<? echo base64_encode($row['name']);?>"><h3><?echo $row['name'];?></h3></a>
										Joined <?echo $row['datereg'];?> - <?echo LevelTag($row['level']);?>
									</div>
									</div>
									<br/>
								<?
								}
								echo '</div>';
							}
							else {
								echo '<h1>There are no Results to "'.$seach.'"</h1>';
							}
							mysql_free_result( $sql );
						}
						else {
							echo '<h1>Please type a valid username.</h1>';
						}
					}
					
					else if ( $act == 'top' ) {
						$top = array (
							"kills" => "Best Killers",
							"spree" => "Players whit more Spree's",
							"joins" => "Players with more Joins",
							"pickups" => "Best Search",
							"playedtime" => "Players with more playing Time",
							"cash" => "Players with more cash",
						);
						foreach( $top as $sql => $name ) {
							$torow = $sql;
							$sql = mysql_query( "select * from users order by $sql desc limit 0,10" );
							echo '<h1>'.$name.'</h1>
								<table class="hovertable">';
							while( $row = mysql_fetch_assoc( $sql ) ) {
								$name = $row["name"];
								if ( $torow == "playedtime" ) { 
									$show = mktimefromsecs( $row[ $torow ] );
								}
								else if ( $torow == "cash" ) {
									$show = '$'.number_format( $row[ $torow ], 0, '', ',' );
								}
								else $show = $row[ $torow ];
								echo '<tr>
									<td class="first">'.$name.'</td>
									<td class="second">'.$show.'</td>
									</tr>';
							}
							echo '</table>';
							mysql_free_result( $sql );
						}
					}
					
					else if ( $act == 'staff' ) {
						$q = mysql_query( "select * from users where level >= 2 order by level desc" );
						echo '<h1>'.$page_["server_name"].' Staff</h1>
							<p><spam>- This Users are the Group Staff:</spam></p>
							<div class="box01">';
						while( $row = mysql_fetch_assoc( $q ) ) {
							?>
							&raquo; <a class="link01" href="?action=profile&player=<? echo base64_encode($row['name']);?>"><b><?echo $row['name'];?></b></a> - <?echo LevelTag($row['level']);?>
							<br/>
							<?
						}
						echo '</div>';
						mysql_free_result( $q );
					}
					else if ( $act == 'irc_chat' ) { ?>
						<h1>IRC Network</h1>
						<p>You can either use the applet below to connect to the IRC or connect using the following details.
						<ul>
							<li><b>IRC Server: </b><?echo $page_["bot_netname"];?></li> 				
							<li><b>IRC Channel: </b><?echo $page_["bot_chan"];?></li> 				
						</ul>
						</p>
						<p>
						<br/>
						<br/>
						<iframe class="mibbitchat" width="850" height="700" src="http://widget.mibbit.com/?settings=4dbd3e454e99621182efeddb4eb6a6f4&amp;server=<?echo $page_["bot_netname"];?>&amp;nick=<?echo $pinfo["name"];?>&amp;channel=%23<? echo str_replace( '#', '', $page_['bot_chan']);?>"></iframe>
						</p>		
					<?
					}
					else if ( $act == 'members' ) {
						$limit_result = 10;
						$page = ( isset( $_GET["page"] ) ? $_GET["page"]:null); 
						if ( !$page ) { 
							 $start = 0; 
							 $page = 1; 
						} 
						else { 
							$start = ( $page - 1 ) * $limit_result; 
						}
						$ssql = "select * from users"; 
						$rs = mysql_query( $ssql ); 
						$reg_total = mysql_num_rows( $rs ); 

						$total_page = ceil( $reg_total / $limit_result ); 
						echo '<h1 align="center">'.$page_['server_name'].' Member List</h1>';
						echo '
							<div class="box01">
							<p><spam>- The Server have '.$reg_total.' members.</spam></p>
							<p>Page: '.$page.' of '.$total_page.'</p>
						';
						
						$ssql = "select * from users limit ".$start.",".$limit_result; 
						$rs = mysql_query( $ssql ); 
						while ( $row = mysql_fetch_assoc( $rs ) ) { 
						?>
							<div class="box01" style="width:500px; min-height:80px;">
							<div>
								<img style="float:right;width:30px;height:40px;" title="Status on server" src="/files/resources/icons/<?echo( $row["isonline"] == "true" ? "online":"offline")?>.png">
								<img style="width:50px;height:70px;border-radius:10px;float:left;" src="<?echo ParseAvatar( $row["avatar"] );?>"/>
								<a class="link01" href="?action=profile&player=<? echo base64_encode($row['name']);?>"><h3><?echo $row['name'];?></h3></a>
								Joined <?echo $row['datereg'];?> - <?echo LevelTag($row['level']);?>
							</div>
							</div>
							<br/>
						<?
						}
						mysql_free_result( $rs );
						if ( $total_page > 1 ){ 
							for ( $i = 1; $i <= $total_page; $i++ ){ 
								 if ( $page == $i ) {
									 echo $page." "; 
								}
								else {
									 echo "<a style=\"text-decoration:none; font-size:0.9em; font-weight:bold; color:blue;\" href=\"?action=members&page=".$i."\">".$i."</a> ";
								}
							} 
						}
						echo '</div>';
					}
					
					
					else if ( $act == 'store' ) {
						?>
						<br/>
						<br/>
						<div id="box_store" style="width:620px; height:200px; margin: 0 auto;">
						<h1 id="title_store" style="color:#ffffff;"></h1>
						<span id="store_corrent">Vehicles</span> - <a onclick="show_store_vo(3); return false;" href="#" style="text-decoration:none; font-size:0.9em; font-weight:bold; color:blue;"><span id="store_ot">Properties</span></a>
						<p style="color:#ffffff;" id="store_info"></p>
						<p style="color:#ffffff;">- Cash: $<?echo number_format( $pinfo["cash"], 0, '', ',' );?> - Bank: $<?echo number_format( $pinfo["bank"], 0, '', ',' );?></p>
						<div style="z-index:7; float:right;">
						<input value="Seach ID..." onchange="show_store_vo(6);" id="find_id"/>
						<br/>
						<input value="Seach Name..." onchange="show_store_vo(7);" id="find_name"/>
						</div>
						<br/>
						<span style="position:relative; float:left;"><a onclick="show_store_vo(2); return false;" href="#"><img alt="Back" src="/files/resources/img/f_back.png"></img></a></span>
						<div style="z-index:0; width:450px; height:100px; position:absolute; padding:5px; left:25%;" id="ax_store_show"></div>
						<span style="position:relative; float:right;"><a onclick="show_store_vo(1); return false;" href="#"><img alt="Next" src="/files/resources/img/f_nex.png"></img></a></span>
						<br/>
						<br/>
						</div>
						
						<script language="JavaScript">
						var sVar = new function() {
							this.iWork = 1;
							this.dWork = 0;
							this.aInfo = null;
							this.Show = new function() {
								this.Id = 0;
								this.Place = [ "cars", "props" ];
								this.pNames = [ "Vehicles", "Properties" ];
							};
						};		
						var ax_pass = ax_myvar;
						var response = document.getElementById('ax_store_show');
						
						function show_store( place, id ) {
							showlayer( 'load_bar', true );
							var ax = objajax();
							ax.open( 'GET', "ajax.php?ax=get_store&uc=" + ax_pass + "&place=" + place + "&id=" + id );
							ax.onreadystatechange = function() {
								if ( ax.readyState == 4 ) {
									response.innerHTML = ax.responseText;
									showlayer('store_info_');
									document.getElementById("find_id").value = id;
									showlayer( 'load_bar', false );
								}
							}
							ax.send( null );
						}
						function get_store_max() {
							if ( sVar.dWork == 0 ) {
								return parseInt( sVar.aInfo[ 0 ] );
							}
							else {
								return parseInt( sVar.aInfo[ 2 ] );
							}
						}
						function show_store_vo( x ) {
							switch( x ) {
								//Next Item
								case 1:
									if ( sVar.iWork < get_store_max() ) {
										sVar.iWork++;
										show_store( sVar.Show.Place[ sVar.dWork ], sVar.iWork );
									}
								break;
								case 2:
								//Prev. Item
									if ( sVar.iWork > 1 ) {
										sVar.iWork--;
										show_store( sVar.Show.Place[ sVar.dWork ], sVar.iWork );
									}
								break;
								//Change Place
								case 3:
									var cur = document.getElementById("store_corrent");
									var oth = document.getElementById("store_ot");
									sVar.iWork = 1;
									if ( sVar.dWork == 1 ) {
										oth.innerHTML = sVar.Show.pNames[ sVar.dWork ];
										sVar.dWork = 0;
									}
									else {
										oth.innerHTML = sVar.Show.pNames[ sVar.dWork ];
										sVar.dWork = 1;
									}
									cur.innerHTML = sVar.Show.pNames[ sVar.dWork ];
									show_store( sVar.Show.Place[ sVar.dWork ], sVar.iWork );
									show_store_vo( 4 );
								break;
								case 4:
									var show = document.getElementById("title_store");
									show.innerHTML = sVar.Show.pNames[ sVar.dWork ];
									show_store_vo( 5 );
								break;
								case 5:
									var i_show = document.getElementById("store_info"), res, show, ax;
									ax = objajax();
									ax.open( 'GET', "ajax.php?ax=get_info_store&uc=" + ax_pass );
									ax.onreadystatechange = function() {
										if ( ax.readyState == 4 ) {
											res = ax.responseText.split( '#' );
											sVar.aInfo = res;
											show = " - Total Cars: "+res[0]+" Sold: "+res[1]+" Aviable: "+( res[0] - res[1] )+"<br/> - Total Properties: "+res[2]+" Sold: "+res[3]+" Available: "+( res[2] - res[3] )+".";
											i_show.innerHTML = show;
										}
									}
									ax.send( null );
								break;
								case 6:
									showlayer('load_bar',true);
									var val = parseInt( document.getElementById("find_id").value );
									var max = get_store_max();
									if ( typeof val == 'number' && val > 0 && val <= max ) {
										sVar.iWork = val;
										show_store( sVar.Show.Place[ sVar.dWork ], sVar.iWork );
									}
									showlayer('load_bar',false);
								break;
								case 7:
									/*showloadbar();
									var ax = objajax();
									ax.open();
									showloadbar();*/
								break;
							}
						}
						show_store_vo( 4 );
						show_store( sVar.Show.Place[ sVar.dWork ], sVar.iWork );
						</script>
						<br/>
						<?
					}
					
					else if ( $act == 'log_out' ) { session_destroy(); ?>
						<script language="JavaScript">window.location.href='?';</script>
					<?
					}
					else if ( $act == 'error_403' ) {
						echo '<h1><p>Error 403 - Forbidden</p></h1>
						<img border="1" width="500" height="500" src="/files/resources/img/e403.jpg"/>';
						$act = 'error';
					} else {
						$act = 'error';
						?>
						<h1>Error 404 - Page No Found</h1>
						<div id="pagecontent" class = "terminal">
						<div id="msg"><span id="cursor"><img src="/files/resources/cursor.gif" alt="" />&nbsp;</span></div>
						<script type="text/javascript">
						
						if (typeof(jQuery) != "undefined")
						var $j = jQuery.noConflict();

						$ = function() {
						  var elements = new Array();
						  for (var i = 0; i < arguments.length; i++) {
							var element = arguments[i];
							if (typeof element == 'string')
							  element = document.getElementById(element);

							if (arguments.length == 1)
							  return element;

							elements.push(element);
						  }

						  return elements;
						}

						String.prototype.trim = function()
						{
						  a = this.replace(/^\s+/, '');
						  return a.replace(/\s+$/, '');
						}
						var terminal = {
						  cmdIdx: 0,
						  currentCommand: null,
						  pos: 0,
						  prompt: "root@nt5:~ ",
						  screen: null,
						  init: function(obj) {
							terminal.screen = obj;
							terminal.nextCommand();
						  },

						  nextCommand: function() {
							if (terminal.cmdIdx < msg.length) {
							  terminal.startCommand();
							}
						  },
						  
						  startCommand: function() {
							var pauseInterval = 0;
							terminal.currentCommand = msg[terminal.cmdIdx];
							node = document.createElement("span"); node.innerHTML = terminal.prompt;
							terminal.screen.appendChild(node);
							
							terminal.typeCommand();
						  },
						  
						  typeCommand: function() {
							var pauseInterval = 100;
							var node;
							
							if (terminal.currentCommand.cmd && (terminal.pos < terminal.currentCommand.cmd.length)) {
							  var ch = terminal.currentCommand.cmd.substr(terminal.pos, 1);
							  terminal.pos++;
							  
							  switch (ch.charCodeAt(0)) {
								case 125: { node = document.createElement("br"); break; }
								case 94: { pauseInterval = 1000; break; }
								default: { node = document.createTextNode(ch); break; }
							  }
							  
							  if (node != null) terminal.screen.appendChild(node);
							  $j("#cursor").remove().appendTo($j(terminal.screen));
							  
							  if (pauseInterval > 0)
								setTimeout(terminal.typeCommand, pauseInterval)
							  else
								terminal.typeCommand();
							}
							else
							  terminal.showResponse();
						  },
						  
						  showResponse: function() {
							terminal.pos = 0;
							if (terminal.currentCommand.response != null)
							  terminal.screen.appendChild(document.createTextNode(terminal.currentCommand.response));
							if (terminal.currentCommand.br)
							  terminal.screen.appendChild(document.createElement("br"));
							$j("#cursor").remove().appendTo($j(terminal.screen));
							terminal.cmdIdx++;
							terminal.nextCommand();
						  }

						  
						}
						  var msg = [
							{cmd: "404^}", response: "404: command not found", br: true},
							{cmd: "^locate 404}^^", response: "", br: false},
							{cmd: "^find 404}^^", response: "find: 404: No such file or directory", br: true},
							{cmd: "^where are you???}", response: "where: command not found", br: true},
							{cmd: "^^}}HTTP 404. File not found.^}Sorry. The page you are looking for is not here.", response: null, br: false}
						  ];

						  $j(document).ready( function() { terminal.init($("msg")); } ); 
						</script>
						</div>
						<?
					}
					?>
						<div id="comments_box" style="display:none;">
							<a onclick="showlayer('comments_box'); return false;" style="float:right;" href="#"><img src="/files/resources/icons/x.png"/></a>
							<div id="comments"></div>
					<?
					if ( !in_array( $act, $forb_pages ) ) {
						switch( $act ) {
							case "profile":
								if ( $_GET['player'] ) {
									$sec = $act.";".base64_decode( $_GET['player'] );						
								}
							break;
							case "group":
								if ( $_GET['urc'] && $_GET['w'] ) {
									$sect = $_GET['urc'];
									$watch = $_GET['w'];
									switch( $sect ) {
										case "clan":
											$sec = $act.";".$sect.";".base64_decode( $watch );
										break;
									}
								}
							break;
							default:
								$sec = $act;
							break;
						}
						if ( $sec ) {
							echo '
								<div>
								<br/>
								<p>New Comment</p>
								<input id="new_comment" type="text" maxlength="100"/>
								<input type="button" value="Post" class="yourclass" onclick="NewComment( \''.$sec.'\' );"/>
								</div>
							';
						}
					}
					echo '</div>';
				}
				else {
				?>
					<div class="form_log" id="login">
					<form id="login" name="login1" action="?" method="post">
						<h1>Need Login to see web page!</h1>
						<p>Enter the data you used to register on the server.</p>
							<label>User<span class="small">Add your Nick name</span></label>
							<input id = "log_user" type="text" name="user" size="20" maxlength="100" onChange="ExistPlayer();"/>
							<div id="com_log01" style="display:none;"><img src="/files/resources/icons/x.png"></div>
							<label>Password<span class="small">Input correct password</span></label>
							<div id="com_log02" style="display:none;"><img src="/files/resources/icons/x.png"></div>
							<input id = "log_pass" type="password" name="pass" size="20" maxlength="100"/>
							<button type="submit" name="Login" class="boton01">Login</button>
					</form>
					</div>
				<?
				}
			?>
			</div>
				<!-- end of content -->
				<div id="footer">
					<p>� Copyright NT5 2012 - 2013 VC:MP Script.</p>
				</div>
		</div><!-- end of wrap -->
	</div><!-- end of container -->
	<div id="gotop" style="display:none;"><a href="#top"><span/></a></div>
	<?
	if ( isset ( $sec ) && $Logged ) {
		if ( $sec ) {
			echo '
				<div class="comments_float"><a onclick="GetComments(\''.$sec.'\'); return false;" class="link01" style="color:#ffffff;" href="#"><img src="/files/resources/icons/comment.gif"/>Comments</a></div>
			';
		}
	}
	?>
</body>
</html>  

<?php
	mysql_close( $db );
?>