<?php
if ( isset( $_GET['plr'] ) ) {
	include 'config.php';
	
	$player64 = base64_decode( $_GET['plr'] );
	$db = @mysql_connect( $mysql_host, $mysql_user, $mysql_pass );
	if ( $db ) {
		mysql_select_db( $mysql_data );
		
		$sql = mysql_query( "select * from users where name = '".$player64."'" );
		$img = imagecreatefrompng("./files/resources/img/signature.png");
		$colors = array (
			"black" => imagecolorallocate($img, 0, 0, 0),
			"white" => imagecolorallocate($img, 255, 255, 255),
			"gray" => imagecolorallocate($img, 105, 105, 105),
			"blue" => imagecolorallocate($img, 0, 0, 255),
			"green" => imagecolorallocate($img, 0, 255, 0),
			"red" => imagecolorallocate($img, 255, 0, 0)
		);
		$textcol = $colors["white"];
		if ( mysql_num_rows( $sql ) > 0 ) {
			$player = mysql_fetch_assoc( $sql );
			imagestring( $img, 5, 10, 46, $player["name"], $textcol );
			imagestring( $img, 5, 10, 73, ( $player["isonline"] == "true" ? "Online":"Offline" ), ( $player["isonline"] == "true" ? $colors["green"]:$colors["red"] ) );
			imagestring( $img, 5, 160, 48, "Kills: ".$player["kills"], $textcol );
			imagestring( $img, 5, 160, 68, "Deaths: ".$player["deaths"], $textcol );
			imagestring( $img, 5, 285, 48, "Ratio: ".( $player["deaths"] > 0 && $player["kills"] > 0 ? round( $player["kills"] / $player["deaths"], 2 ):"0" ), $textcol );
			imagestring( $img, 5, 285, 68, "Joins: ".$player["joins"], $textcol );
			imagestring( $img, 5, 410, 68, "Props: ".$player["cprops"], $textcol );
			imagestring( $img, 5, 410, 48, "Cars: ".$player["ccars"], $textcol );
			mysql_free_result( $sql );
		}
		else {
			imagestring( $img, 5, 205, 60, "/!\ Unknown Player Name", $colors["red"] );
		}
		header("Content-type: image/png");
		imagepng( $img );
		imagedestroy( $img );
		mysql_close( $db );
	}
}
?>