To build the module run
 nmake /F Makefile.vc
from the Visual Studio Command Prompt

The GeoIP dependencies are included for win32 in the libGeoIPwin32, if
u want to build GeoIP.lib, good luck with it... change the GeoIP path in
Makefile.vc after you're done.

For help see
 http://vcmp.liberty-unleashed.co.uk/forum/index.php?topic=925.0
or on IRC:
 eeew @ LUNet or irc.godclan.hu or irc.gtanet.com

