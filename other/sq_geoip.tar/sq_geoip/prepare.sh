#!/usr/bin/env bash

wget -OGeoIP.tar.gz http://www.maxmind.com/download/geoip/api/c/GeoIP-1.4.8.tar.gz
tar xzf GeoIP.tar.gz
rm -f GeoIP.tar.gz
cd GeoIP-*
libtoolize
CFLAGS=-m32 ./configure
make CFLAGS=-m32
cd ..